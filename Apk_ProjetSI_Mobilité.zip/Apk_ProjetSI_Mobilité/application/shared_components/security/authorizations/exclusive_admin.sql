prompt --application/shared_components/security/authorizations/exclusive_admin
begin
--   Manifest
--     SECURITY SCHEME: EXCLUSIVE ADMIN
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_security_scheme(
 p_id=>wwv_flow_api.id(31628016419017674465)
,p_name=>'EXCLUSIVE ADMIN'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Administrateur'
,p_attribute_02=>'A'
,p_error_message=>unistr('L''utilisateur n''a pas les droits d''acc\00E8s de l''administrateur.')
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_api.component_end;
end;
/
