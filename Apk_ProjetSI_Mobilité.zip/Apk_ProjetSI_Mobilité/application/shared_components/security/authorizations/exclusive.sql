prompt --application/shared_components/security/authorizations/exclusive
begin
--   Manifest
--     SECURITY SCHEME: EXCLUSIVE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_security_scheme(
 p_id=>wwv_flow_api.id(32833300527008468702)
,p_name=>'EXCLUSIVE'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>'return TRUE;'
,p_error_message=>unistr('Probl\00E8me d''autorisation')
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_api.component_end;
end;
/
