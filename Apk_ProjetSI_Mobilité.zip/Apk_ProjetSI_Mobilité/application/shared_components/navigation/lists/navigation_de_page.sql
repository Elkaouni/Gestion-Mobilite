prompt --application/shared_components/navigation/lists/navigation_de_page
begin
--   Manifest
--     LIST: Navigation de page
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(31617205906385975464)
,p_name=>'Navigation de page'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617206380916975465)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Pool'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 3 or profile = 4 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617206796277975465)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Filiere'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 3 or profile = 4 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617207195770975466)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('El\00E8ves 2A')
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 3 or profile = 4 or profile = 1 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617207504892975466)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Charger liste 2A'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 1 or profile = 3 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_api.id(31617207195770975466)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617209106580975466)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Importer notes'
,p_list_item_link_target=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 3 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_api.id(31617207195770975466)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617208738192975466)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Modules'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 3 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617209514221975467)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Ecoles partenaires'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 4 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617209934411975467)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Utilisateurs'
,p_list_item_link_target=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 1 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617210308900975467)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Seuils'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 3  then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617210772834975467)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Nombre de places'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 4 or profile = 2 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40141460138907287105)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Mon desiderata '
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 2 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40562965429446819686)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('Contr\00F4le d''acc\00E8s')
,p_list_item_link_target=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 1then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40562974912321825211)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Gestion des menus'
,p_list_item_link_target=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'profile number;',
'begin ',
'select profile_fk into profile from APP_USERS where lower(username) = lower(:APP_USER);',
'if profile = 1 then return true;',
'else return false; ',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
