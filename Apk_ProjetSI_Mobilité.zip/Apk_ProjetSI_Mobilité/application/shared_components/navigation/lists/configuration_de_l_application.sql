prompt --application/shared_components/navigation/lists/configuration_de_l_application
begin
--   Manifest
--     LIST: Configuration de l'application
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(31617362935447976477)
,p_name=>'Configuration de l''application'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_api.id(31616915875317974309)
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617363384808976477)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Options de configuration'
,p_list_item_link_target=>'f?p=&APP_ID.:10010:&SESSION.::&DEBUG.:10010:::'
,p_list_item_icon=>'fa-sliders'
,p_list_text_01=>unistr('Activer ou d\00E9sactiver des fonctionnalit\00E9s de l''application')
,p_required_patch=>wwv_flow_api.id(31616915875317974309)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
