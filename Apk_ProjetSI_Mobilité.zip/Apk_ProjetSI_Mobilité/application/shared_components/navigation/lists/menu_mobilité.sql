prompt --application/shared_components/navigation/lists/menu_mobilité
begin
--   Manifest
--     LIST: Menu Mobilité
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(32633359569278664181)
,p_name=>unistr('Menu Mobilit\00E9')
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LEVEL, ',
'"mob_menu"."name" label,',
'''f?p=&APP_ID.:''||"mob_menu"."tag"||'':''||:APP_SESSION||'':::::'' target,',
'"mob_menu"."name" as is_current, ',
'"mob_menu"."icon" image',
'from "mob_menu"',
'where "mob_menu"."id"in (select MENU from "USER_ACCESS" ',
'where "USER_ACCESS"."PROFILE"=(select PROFILE_FK from "APP_USERS" ',
'where lower("APP_USERS"."USERNAME")= lower(:APP_USER)))',
'start with "pid" is null',
'connect by prior "id" = "pid"',
'order siblings by "id"'))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
