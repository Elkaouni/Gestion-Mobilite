prompt --application/shared_components/navigation/lists/navigation_de_page_coordinateur
begin
--   Manifest
--     LIST: Navigation de page coordinateur
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(32648049261724114066)
,p_name=>'Navigation de page coordinateur'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32648049412252114067)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Pool'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32648049829685114067)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Fili\00E8re')
,p_list_item_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32648050235779114068)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Ecoles'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32648050647089114068)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Nombre de places'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
