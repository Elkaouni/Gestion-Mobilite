prompt --application/shared_components/navigation/lists/navigation_de_page_administrateur
begin
--   Manifest
--     LIST: Navigation de page administrateur
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(33178131953181136350)
,p_name=>'Navigation de page administrateur'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33181216199701151203)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Personnalisation des menus'
,p_list_item_link_target=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33179655390711144784)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Gestion des acc\00E8s')
,p_list_item_link_target=>'f?p=&APP_ID.:41:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-universal-access'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33179627898997131517)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('El\00E8ves 2A')
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-graduation-cap'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33178136190907136354)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Seuils'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
