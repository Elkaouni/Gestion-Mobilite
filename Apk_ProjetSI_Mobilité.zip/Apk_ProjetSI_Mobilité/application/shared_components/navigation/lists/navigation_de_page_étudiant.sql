prompt --application/shared_components/navigation/lists/navigation_de_page_étudiant
begin
--   Manifest
--     LIST: Navigation de page étudiant
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(39740665909991182679)
,p_name=>unistr('Navigation de page \00E9tudiant')
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(39746751205061228935)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>unistr('Choix de mobilit\00E9')
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
