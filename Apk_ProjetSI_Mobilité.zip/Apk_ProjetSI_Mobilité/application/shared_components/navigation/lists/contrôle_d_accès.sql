prompt --application/shared_components/navigation/lists/contrôle_d_accès
begin
--   Manifest
--     LIST: Contrôle d'accès
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(31617367003434976479)
,p_name=>unistr('Contr\00F4le d''acc\00E8s')
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_api.id(31616915412552974309)
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617367470045976479)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Utilisateurs'
,p_list_item_link_target=>'f?p=&APP_ID.:10041:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>unistr('Modifier les param\00E8tres de contr\00F4le d''acc\00E8s et d\00E9sactiver le contr\00F4le d''acc\00E8s')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31617367819119976479)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Contr\00F4le d''acc\00E8s')
,p_list_item_link_target=>'f?p=&APP_ID.:10040:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_list_text_01=>unistr('D\00E9finir le niveau d''acc\00E8s des utilisateurs authentifi\00E9s de cette application')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
