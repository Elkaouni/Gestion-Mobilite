prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 100711
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_app_setting(
 p_id=>wwv_flow_api.id(31616919159101974312)
,p_name=>'FEEDBACK_ATTACHMENTS_YN'
,p_value=>'Y'
,p_is_required=>'N'
,p_valid_values=>'Y, N'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_api.id(31616915613974974309)
);
wwv_flow_api.create_app_setting(
 p_id=>wwv_flow_api.id(31616919409055974312)
,p_name=>'ACCESS_CONTROL_SCOPE'
,p_value=>'ACL_ONLY'
,p_is_required=>'N'
,p_valid_values=>'ACL_ONLY, ALL_USERS'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_api.id(31616915412552974309)
,p_comments=>unistr('Niveau d''acc\00E8s par d\00E9faut attribu\00E9 aux utilisateurs authentifi\00E9s qui ne figurent pas dans la liste de contr\00F4le d''acc\00E8s')
);
wwv_flow_api.component_end;
end;
/
