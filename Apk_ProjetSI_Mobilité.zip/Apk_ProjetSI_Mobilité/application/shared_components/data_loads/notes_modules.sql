prompt --application/shared_components/data_loads/notes_modules
begin
--   Manifest
--     DATA LOAD: Notes_Modules
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_data_profile(
 p_id=>wwv_flow_api.id(39531057487128571936)
,p_name=>'Notes_Modules'
,p_format=>'XLSX'
,p_encoding=>'utf-8'
,p_default_xlsx_sheet_name=>'sheet1.xml'
,p_has_header_row=>true
);
wwv_flow_api.create_data_profile_col(
 p_id=>wwv_flow_api.id(39531057823732571985)
,p_data_profile_id=>wwv_flow_api.id(39531057487128571936)
,p_name=>'NOTE'
,p_sequence=>10
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_selector_type=>'NAME'
,p_selector=>'NOTE'
);
wwv_flow_api.create_load_table(
 p_id=>wwv_flow_api.id(39531058063730571985)
,p_name=>'Notes_Modules'
,p_static_id=>'Notes_Modules'
,p_target_type=>'TABLE'
,p_table_name=>'ETUDIANT_MODULES'
,p_data_profile_id=>wwv_flow_api.id(39531057487128571936)
,p_loading_method=>'APPEND'
,p_commit_interval=>200
,p_error_handling=>'ABORT'
,p_skip_validation=>'N'
);
wwv_flow_api.component_end;
end;
/
