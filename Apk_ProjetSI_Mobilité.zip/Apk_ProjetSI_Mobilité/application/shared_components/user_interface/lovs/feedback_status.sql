prompt --application/shared_components/user_interface/lovs/feedback_status
begin
--   Manifest
--     FEEDBACK_STATUS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(31617342232047976459)
,p_lov_name=>'FEEDBACK_STATUS'
,p_lov_query=>'.'||wwv_flow_api.id(31617342232047976459)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(31617342591422976459)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Aucune action'
,p_lov_return_value=>'0'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(31617342910427976460)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('R\00E9ception confirm\00E9e')
,p_lov_return_value=>'1'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(31617343378388976460)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Ouvert'
,p_lov_return_value=>'3'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(31617343779773976460)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('Ferm\00E9')
,p_lov_return_value=>'4'
);
wwv_flow_api.component_end;
end;
/
