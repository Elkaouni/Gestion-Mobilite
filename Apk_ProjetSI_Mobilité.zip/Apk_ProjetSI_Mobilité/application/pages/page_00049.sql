prompt --application/pages/page_00049
begin
--   Manifest
--     PAGE: 00049
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>49
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>unistr('Chargement des notes des \00E9l\00E8ves')
,p_alias=>unistr('CHARGEMENT-DES-NOTES-DES-\00C9L\00C8VES')
,p_step_title=>unistr('Chargement des notes des \00E9l\00E8ves')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'YOUSRA'
,p_last_upd_yyyymmddhh24miss=>'20220221193725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39918280549348447080)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616828752682974268)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(31616725863228974225)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(31616890825385974294)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(106044156213673589438)
,p_plug_name=>'Barre de boutons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_api.id(31616765079390974245)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P49_FILE'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(106044158146061589440)
,p_plug_name=>unistr('Source de donn\00E9es')
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(31616816680959974263)
,p_plug_display_sequence=>50
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(106044158587706589440)
,p_plug_name=>unistr('T\00E9l\00E9charger un fichier')
,p_parent_plug_id=>wwv_flow_api.id(106044158146061589440)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616762263951974244)
,p_plug_display_sequence=>30
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P49_FILE'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(106044160593353589442)
,p_plug_name=>unistr('Fichier charg\00E9')
,p_parent_plug_id=>wwv_flow_api.id(106044158146061589440)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616762263951974244)
,p_plug_display_sequence=>40
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P49_FILE'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(106044163531738589444)
,p_name=>unistr('Pr\00E9visualiser')
,p_template=>wwv_flow_api.id(31616816680959974263)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.line_number,',
'       p.col001, p.col002, p.col003, p.col004, p.col005, ',
'       p.col006, p.col007, p.col008, p.col009, p.col010, p.col011',
'       -- add more columns (col011 to col300) here.',
'  from apex_application_temp_files f, ',
'       table( apex_data_parser.parse(',
'                  p_content           => f.blob_content,',
'                  p_file_name         => f.filename,',
'                  p_xlsx_sheet_name   => case when :P49_XLSX_WORKSHEET is not null then :P49_XLSX_WORKSHEET end,',
'                  p_file_profile      => apex_data_loading.get_file_profile( p_static_id => ''Donn_es_Etudiants''),',
'                  p_max_rows          => 100 ) ) p',
' where f.name = :P49_FILE'))
,p_display_when_condition=>'P49_FILE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(31616854243644974279)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('aucune donn\00E9e n''a \00E9t\00E9 trouv\00E9e')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39880810169403388548)
,p_query_column_id=>1
,p_column_alias=>'LINE_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Line Number'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918277670749447078)
,p_query_column_id=>2
,p_column_alias=>'COL001'
,p_column_display_sequence=>20
,p_column_heading=>'Col001'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918278096176447078)
,p_query_column_id=>3
,p_column_alias=>'COL002'
,p_column_display_sequence=>30
,p_column_heading=>'Col002'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918278428625447079)
,p_query_column_id=>4
,p_column_alias=>'COL003'
,p_column_display_sequence=>40
,p_column_heading=>'Col003'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918278898987447079)
,p_query_column_id=>5
,p_column_alias=>'COL004'
,p_column_display_sequence=>50
,p_column_heading=>'Col004'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918279202846447079)
,p_query_column_id=>6
,p_column_alias=>'COL005'
,p_column_display_sequence=>60
,p_column_heading=>'Col005'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918279641197447079)
,p_query_column_id=>7
,p_column_alias=>'COL006'
,p_column_display_sequence=>70
,p_column_heading=>'Col006'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918280071652447079)
,p_query_column_id=>8
,p_column_alias=>'COL007'
,p_column_display_sequence=>80
,p_column_heading=>'Col007'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918276010697447077)
,p_query_column_id=>9
,p_column_alias=>'COL008'
,p_column_display_sequence=>90
,p_column_heading=>'Col008'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918276438542447077)
,p_query_column_id=>10
,p_column_alias=>'COL009'
,p_column_display_sequence=>100
,p_column_heading=>'Col009'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39918276837678447078)
,p_query_column_id=>11
,p_column_alias=>'COL010'
,p_column_display_sequence=>110
,p_column_heading=>'Col010'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39880810201112388549)
,p_query_column_id=>12
,p_column_alias=>'COL011'
,p_column_display_sequence=>130
,p_column_heading=>'Col011'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39918274098859447074)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(106044156213673589438)
,p_button_name=>'CLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_image_alt=>'Effacer'
,p_button_position=>'NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39918274467172447074)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(106044156213673589438)
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Ins\00E9rer les donn\00E9es')
,p_button_position=>'NEXT'
,p_confirm_message=>unistr('\00CAtes-vous s\00FBr de vouloir ins\00E9rer ces donn\00E9es?')
,p_confirm_style=>'information'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39918273606381447074)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(106044156213673589438)
,p_button_name=>'CALCULE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Calculer la moyenne mob'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918271452429447072)
,p_name=>'P49_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(106044158587706589440)
,p_prompt=>unistr('T\00E9l\00E9charger un fichier')
,p_display_as=>'NATIVE_FILE'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_api.id(31616886409239974292)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_06=>'Y'
,p_attribute_08=>'attachment'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'DROPZONE_BLOCK'
,p_attribute_14=>'Formats pris en charge XLSX'
,p_attribute_15=>'5000'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918271804779447072)
,p_name=>'P49_ERROR_ROW_COUNT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(106044158587706589440)
,p_display_as=>'NATIVE_HIDDEN'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918272570079447073)
,p_name=>'P49_FILE_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(106044160593353589442)
,p_item_default=>unistr('Donn\00E9es coll\00E9es')
,p_prompt=>unistr('Fichier charg\00E9')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918272960479447073)
,p_name=>'P49_XLSX_WORKSHEET'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(106044160593353589442)
,p_prompt=>'Feuille de calcul XLSX'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.sheet_display_name,',
'       p.sheet_file_name',
'  from apex_application_temp_files f,',
'       table( apex_data_parser.get_xlsx_worksheets( p_content => f.blob_content ) ) p',
' where f.name = :P49_FILE'))
,p_cHeight=>1
,p_display_when=>'lower( :P31_FILE ) like ''%.xlsx'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(39918281293445447081)
,p_computation_sequence=>10
,p_computation_item=>'P49_FILE_NAME'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename',
'  from apex_application_temp_files ',
' where name = :P49_FILE'))
,p_compute_when=>'P49_FILE'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(39918281610837447081)
,p_validation_name=>'Is valid file type'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_data_parser.assert_file_type(',
'       p_file_name => :P49_FILE_NAME,',
'       p_file_type => apex_data_parser.c_file_type_xlsx )',
'then',
'    return true;',
'else',
'    :P49_FILE := null;',
'    return false;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Type de fichier non valide. Types de fichier pris en charge : XLSX.'
,p_associated_item=>wwv_flow_api.id(39918271452429447072)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39918283110272447082)
,p_name=>unistr('T\00E9l\00E9charger un fichier')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P49_FILE'
,p_condition_element=>'P49_FILE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39918283669187447082)
,p_event_id=>wwv_flow_api.id(39918283110272447082)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39918284001875447082)
,p_name=>'Submit worksheet on change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P49_XLSX_WORKSHEET'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39918284529454447082)
,p_event_id=>wwv_flow_api.id(39918284001875447082)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39918282384359447081)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Effacer le cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST = ''CLEAR'' or :P49_ERROR_ROW_COUNT = 0'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39918281964053447081)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Ins\00E9rer les donn\00E9es')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'     delete from releve_etudiant where (1=1);',
'     insert into releve_etudiant( CNE_ETUDIANT,',
'                        ALGORITHMIQUE_PROGRAMMATION,',
unistr('                        STRUCTURES_DONN\00C9ES,'),
unistr('                        RECHERCHE_OP\00C9RATIONNELLES,'),
unistr('                        PROBABILIT\00C9S_SIMULATION,'),
'                        ECONOMIE,',
'                        COMMUNICATION,',
'                        OS,',
'                        POO,',
'                        ECONOMIE2,',
'                        COMMUNICATION2                        ) ',
'     (SELECT col001 ,',
'            TO_NUMBER( col002 ),',
'            TO_NUMBER( col003 ),',
'            TO_NUMBER( col004 ),',
'            TO_NUMBER( col005 ),',
'            TO_NUMBER( col006 ),',
'            TO_NUMBER( col007 ),',
'            TO_NUMBER( col008 ),',
'            TO_NUMBER( col009 ),',
'            TO_NUMBER( col010 ),',
'            TO_NUMBER( col011 )',
'                        ',
'        FROM apex_application_temp_files f, apex_data_parser.parse      ',
'        (',
'            p_content => f.blob_content,',
'            p_skip_rows => 1,',
'            p_file_type => apex_data_parser.c_file_type_xlsx ',
'        ) ',
'        where f.name = :P49_FILE',
'     );',
'    commit;     ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Erreur lors du chargement des donn\00E9es!')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(39918274467172447074)
,p_process_success_message=>unistr('Data Loaded successfully into Relev\00E9_Etudiant!')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39918282788028447082)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CALCULE_MOY_MOB'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    cursor cursor_etudiants_notes is',
unistr('        select etudiants.id, algorithmique_programmation, structures_donn\00E9es, recherche_op\00E9rationnelles,'),
unistr('                probabilit\00E9s_simulation , economie , communication , os ,  poo , economie2, communication2'),
'        from releve_etudiant re join etudiants ',
'        on re.cne_etudiant = etudiants.cne',
'        where re.cne_etudiant in (select cne from etudiants);',
'',
'',
'    cursor cursor_etudiants is',
'        select etudiants.id, cne from releve_etudiant join etudiants ',
'        on releve_etudiant.cne_etudiant = etudiants.cne;',
'',
'    v_id etudiants.id%type;',
'    v_cne etudiants.cne%type;',
'    v_id_etudiant etudiant_modules.etudiants_id%type;',
'    v_algo number;',
'    v_struct number;',
'    v_rechOp number;',
'    v_proba number;',
'    v_eco number;',
'    v_comm number;',
'    v_os number;',
'    v_poo number;',
'    v_eco2 number;',
'    v_comm2 number;',
'    v_moy_mob etudiants.moy_mob%type;',
'',
'begin',
'    open cursor_etudiants;',
'    LOOP',
'        FETCH cursor_etudiants INTO v_id, v_cne;',
'        v_moy_mob:=0;',
'        EXIT WHEN cursor_etudiants%NOTFOUND;',
'        open cursor_etudiants_notes;',
'        loop',
'            FETCH cursor_etudiants_notes INTO v_id_etudiant, v_algo, v_struct, v_rechOp , v_proba, ',
'            v_eco , v_comm, v_os, v_poo,  v_eco2, v_comm2 ;',
'            EXIT WHEN cursor_etudiants_notes%NOTFOUND;',
'            if(v_id = v_id_etudiant) then',
'                v_moy_mob := v_algo + v_struct+ v_rechOp+ v_proba+v_eco +v_comm+v_os+v_poo+v_eco2+ v_comm2;',
'                exit;',
'            END IF;',
'        end loop;',
'        close cursor_etudiants_notes;',
'        v_moy_mob := v_moy_mob/10;',
'        update etudiants set moy_mob = round(v_moy_mob,2) where etudiants.id = v_id;',
'        commit;',
'    END LOOP;',
'    close cursor_etudiants;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Erreur lors des calculs'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(39918273606381447074)
,p_process_success_message=>unistr('Moyenne mobilit\00E9 calcul\00E9 avec succ\00E8s')
);
wwv_flow_api.component_end;
end;
/
