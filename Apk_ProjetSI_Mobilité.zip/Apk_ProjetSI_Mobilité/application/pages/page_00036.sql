prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>36
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>unistr('Contr\00F4le d''acc\00E8s')
,p_alias=>unistr('CONTR\00D4LE-D-ACC\00C8S')
,p_step_title=>unistr('Contr\00F4le d''acc\00E8s')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220221110949'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40631486964086528448)
,p_plug_name=>'Etat 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616812390454974262)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'VUE_MENU_PERSONNALISE'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Etat 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(40631487352002528448)
,p_name=>'Etat 1'
,p_max_row_count_message=>unistr('Le nombre maximal de lignes pour cet \00E9tat est de #MAX_ROW_COUNT# lignes. Appliquez un filtre pour r\00E9duire le nombre d''enregistrements dans votre requ\00EAte.')
,p_no_data_found_message=>unistr('Aucune donn\00E9e n''a \00E9t\00E9 trouv\00E9e.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:RP:P37_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Modifier"><span class="fa fa-edit" aria-hidden="true" title="Modifier"></span></span>'
,p_owner=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_internal_uid=>40631487352002528448
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40631487453294528450)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40631487871880528450)
,p_db_column_name=>'PROFILE_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Profile Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40631488217071528451)
,p_db_column_name=>'MENU_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Menu Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(40631489313399529213)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'406314894'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:PROFILE_NAME:MENU_NAME'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40631488722277528451)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(40631486964086528448)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:37::'
);
wwv_flow_api.component_end;
end;
/
