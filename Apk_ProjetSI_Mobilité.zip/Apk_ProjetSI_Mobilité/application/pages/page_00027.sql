prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>27
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>'Manage Roles'
,p_alias=>'MANAGE-ROLES'
,p_step_title=>'Manage Roles'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(31616919758754974313)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220124232031'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27377498539147002643)
,p_plug_name=>'Apply roles'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(31616816680959974263)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27377499186084002649)
,p_plug_name=>unistr('El\00E9ments exclusifs')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(31616816680959974263)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27377499244771002650)
,p_plug_name=>'Administrateurs'
,p_parent_plug_id=>wwv_flow_api.id(27377499186084002649)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616794549888974255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(31628016419017674465)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33574995850549043501)
,p_plug_name=>'Coordinateurs'
,p_parent_plug_id=>wwv_flow_api.id(27377499186084002649)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616794549888974255)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(31628117032063661428)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33574995938444043502)
,p_plug_name=>'Etudiants'
,p_parent_plug_id=>wwv_flow_api.id(27377499186084002649)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616794549888974255)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(31628169132700688519)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33574996086390043503)
,p_plug_name=>unistr('Scolarit\00E9')
,p_parent_plug_id=>wwv_flow_api.id(27377499186084002649)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616794549888974255)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(31628095781435654936)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27377498898322002646)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(27377498539147002643)
,p_button_name=>'P27_SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enregistrer'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27377498625424002644)
,p_name=>'P27_ROLE_IDS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(27377498539147002643)
,p_prompt=>'Nouveau'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'ACCESS_ROLES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select role_name d, role_id r',
'from APEX_APPL_ACL_ROLES where application_id = :APP_ID ',
'order by 1'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27377499098335002648)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Assigner role'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_roles   wwv_flow_t_number := apex_string.split_numbers(:P27_ROLE_IDS, '':'');',
'BEGIN ',
'    APEX_ACL.REPLACE_USER_ROLES (',
'        p_application_id => :APP_ID,',
'        p_user_name => ''ADMIN'',',
'        p_role_ids => l_roles );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(27377498898322002646)
,p_process_success_message=>unistr('R\00F4le assign\00E9 avec succ\00E8s.')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27377498957665002647)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BEFORE_H'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_roles     varchar2(4000);',
'begin ',
'    select role_ids',
'      into l_roles',
'      from apex_appl_acl_users',
'     where APPLICATION_ID = :APP_ID',
'       and USER_NAME = ''ADMIN'';',
'       --',
'     :P27_ROLE_IDS := l_roles;',
'exception ',
'    when no_data_found then ',
'        :P270001_ROLE_ID := '''';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
