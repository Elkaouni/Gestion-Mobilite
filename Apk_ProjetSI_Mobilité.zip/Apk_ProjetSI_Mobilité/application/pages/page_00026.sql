prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>26
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>'Appliquer les roles'
,p_alias=>'APPLIQUER-LES-ROLES'
,p_step_title=>'Appliquer les roles'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(31616919758754974313)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220121141024'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31629387748247822370)
,p_plug_name=>'Appliquer Roles'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(31616816680959974263)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27377494599646002603)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(31629387748247822370)
,p_button_name=>'Enregistrer'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_image_alt=>'Enregistrer'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27377494406498002602)
,p_name=>'P1_ROLE_IDS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(31629387748247822370)
,p_prompt=>'Roles'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_cattributes_element=>'ACCESS_ROLES'
,p_tag_attributes=>'ACCESS_ROLES'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27377494788884002605)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Assigner role \00E0 user')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_roles   wwv_flow_t_number := apex_string.split_numbers(:P1_ROLE_IDS, '':'');',
'BEGIN ',
'    APEX_ACL.REPLACE_USER_ROLES (',
'        p_application_id => :APP_ID,',
'        p_user_name => ''ADMIN'',',
'        p_role_ids => l_roles );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(27377494599646002603)
,p_process_success_message=>unistr('Op\00E9ration effectu\00E9e avec succ\00E8s.')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27377494674409002604)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Lecture des roles'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_roles     varchar2(4000);',
'begin ',
'    select role_ids',
'      into l_roles',
'      from apex_appl_acl_users',
'     where APPLICATION_ID = :APP_ID',
'       and USER_NAME = ''ADMIN'';',
'       --',
'     :P1_ROLE_IDS := l_roles;',
'exception ',
'    when no_data_found then ',
'        :P10001_ROLE_ID := '''';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
