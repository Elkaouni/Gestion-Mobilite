prompt --application/pages/page_00043
begin
--   Manifest
--     PAGE: 00043
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>43
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>unistr('Affectation des \00E9l\00E8ves')
,p_alias=>unistr('AFFECTATION-DES-\00C9L\00C8VES')
,p_step_title=>unistr('Affectation des \00E9l\00E8ves')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'YOUSRA'
,p_last_upd_yyyymmddhh24miss=>'20220220162254'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(73670876398120765335)
,p_plug_name=>'Etat 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616812390454974262)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'AFFECTATION'
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Etat 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(73670876791784765335)
,p_name=>'Etat 1'
,p_max_row_count_message=>unistr('Le nombre maximal de lignes pour cet \00E9tat est de #MAX_ROW_COUNT# lignes. Appliquez un filtre pour r\00E9duire le nombre d''enregistrements dans votre requ\00EAte.')
,p_no_data_found_message=>unistr('Aucune donn\00E9e n''a \00E9t\00E9 trouv\00E9e.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:RP:P40_ROWID:\#ROWID#\'
,p_detail_link_text=>'<span aria-label="Modifier"><span class="fa fa-edit" aria-hidden="true" title="Modifier"></span></span>'
,p_owner=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_internal_uid=>73670876791784765335
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40725046604316693045)
,p_db_column_name=>'ROWID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'ROWID'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40725048694786693047)
,p_db_column_name=>'CNE'
,p_display_order=>42
,p_column_identifier=>'F'
,p_column_label=>'Cne'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39880809391633388540)
,p_db_column_name=>'TYPE_AFF'
,p_display_order=>52
,p_column_identifier=>'J'
,p_column_label=>'Type Aff'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39880809417175388541)
,p_db_column_name=>'NOM_ECOLE'
,p_display_order=>62
,p_column_identifier=>'K'
,p_column_label=>'Nom Ecole'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(73670889712593767044)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'329458437'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ROWID:CNE:TYPE_AFF:NOM_ECOLE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40725050947688693054)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(73670876398120765335)
,p_button_name=>'AFFECTER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Lancer l''affectation'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39880809551111388542)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Affecter'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    cursor cur_choix is',
'        select ee.etudiant_id, f.pool_id, ee.ecole_id, ee.type_mobilite from ECOLES_ETUDIANTS ee',
'        join etudiants e on ee.ETUDIANT_ID = e.id ',
'        join ecoles on ecoles.id = ee.ecole_id ',
'        join filiere f on e.filiere = f.nom_filiere',
unistr('        where moy_mob >= (select seuil2 from annee where annee = (select max(annee.annee) from annee join nombre_places on nombre_places.annee_id = annee.id)) --on choist l''ann\00E9e apr\00E8s'),
'        order by e.moy_mob desc, ordre asc;',
'    v_choix_etudiant_id ECOLES_ETUDIANTS.etudiant_id%type;',
'    v_choix_ecole_id    ECOLES_ETUDIANTS.ecole_id%type;',
'    v_choix_type_mob    ECOLES_ETUDIANTS.type_mobilite%type;',
'    v_choix_pool        FILIERE.pool_id%type;',
'    v_an annee.annee%type;',
'    aa number;',
'    b number;',
'    cc number;',
'    d number;',
'    ee number;',
'    ff number;',
'    v number;',
'    place number;',
'    pool number;',
'    ',
'begin',
'        select max(annee.annee) into v_an from annee join nombre_places on nombre_places.annee_id = annee.id ; ',
'        select id into v from annee where annee = v_an;',
'',
'        OPEN cur_choix;',
'        LOOP',
'        FETCH cur_choix INTO v_choix_etudiant_id, v_choix_pool, v_choix_ecole_id, v_choix_type_mob;',
'        Exit when cur_choix%NOTFOUND    ;',
'            select count(*) into ee from AFFECTATION_FIFO where id_etudiant = v_choix_etudiant_id ;',
unistr('            if ee = 0 --eleve pas encore affect\00E9'),
'            then',
'                select count(*) into ff from affectation_fifo af',
'                        join nombre_places np on np.ecole_id = af.id_ecole',
'                            join pool on pool.id= np.pool_id',
'                            where af.id_ecole = v_choix_ecole_id',
'                            and pool.id = v_choix_pool ',
'                            and annee_id = v;',
'',
'                if ff = 0 --ecole non encore choisie',
'                then',
'                    INSERT into AFFECTATION_FIFO(id_etudiant, id_ecole, type_aff)',
'                    values (v_choix_etudiant_id, v_choix_ecole_id, v_choix_type_mob);',
unistr('                --si \00E9cole d\00E9j\00E0 choisie'),
'                else',
unistr('                    -- nombre de places DD ou ECH occup\00E9s (depending on type_aff)'),
'                    select count(*) into aa from affectation_fifo af',
'                            join nombre_places np on np.ecole_id = af.id_ecole',
'                            join pool on pool.id= np.pool_id',
'                            where af.id_ecole = v_choix_ecole_id',
'                            and af.type_aff =v_choix_type_mob',
'                            and pool.id = v_choix_pool ',
'                            and annee_id = v;',
'',
'                    if v_choix_type_mob = ''DD'' then',
'                       -- nombre de place DD available for the student''s pool                        ',
'                        select np. PLACES_DD into b from nombre_places np',
'                        join ecoles ec on np.ecole_id = ec.id ',
'                        join pool on pool.id= np.pool_id',
'                        where pool_id = v_choix_pool ',
'                        and ec.id = v_choix_ecole_id ',
'                        and annee_id = v;',
'',
'                        if aa < b',
'                        then',
'                            INSERT into AFFECTATION_FIFO(id_etudiant, id_ecole, type_aff) ',
'                            values (v_choix_etudiant_id, v_choix_ecole_id, v_choix_type_mob);',
'                        end if;',
'',
'                    elsif  v_choix_type_mob = ''ECH'' then                        ',
'                        -- nombre de place ECH available for the student''s pool',
'                        select np. PLACES_ECHANGE into d from nombre_places np',
'                        join ecoles ec on np.ecole_id = ec.id ',
'                        join pool on pool.id= np.pool_id',
'                        where pool_id = v_choix_pool ',
'                        and ec.id = v_choix_ecole_id ',
'                        and annee_id = v;',
'',
'                        if aa < d',
'                        then',
'                            INSERT into AFFECTATION_FIFO(id_etudiant, id_ecole, type_aff) ',
'                            values (v_choix_etudiant_id, v_choix_ecole_id, v_choix_type_mob);',
'                        end if; ',
'                    end if;               ',
'                end if;',
'            end if;',
'        ',
'        END LOOP;',
'        CLOSE cur_choix;',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(40725050947688693054)
);
wwv_flow_api.component_end;
end;
/
