prompt --application/pages/page_10040
begin
--   Manifest
--     PAGE: 10040
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>10040
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>unistr('Configurer le contr\00F4le d''acc\00E8s')
,p_alias=>unistr('CONFIGURER-LE-CONTR\00D4LE-D-ACC\00C8S')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Configurer le contr\00F4le d''acc\00E8s')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(31616919758754974313)
,p_required_role=>wwv_flow_api.id(31616918188552974311)
,p_required_patch=>wwv_flow_api.id(31616915412552974309)
,p_protection_level=>'U'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>S\00E9lectionnez l''option appropri\00E9e pour tous les utilisateurs authentifi\00E9s.<br>'),
unistr('Si vous s\00E9lectionnez <strong>Non</strong>, l''application sera plus s\00E9curis\00E9e, car seuls les utilisateurs sp\00E9cifi\00E9s peuvent y acc\00E9der.'),
unistr('Toutefois, si votre application compte de nombreux utilisateurs, tenir \00E0 jour les utilisateurs peut s''av\00E9rer complexe, et vous pr\00E9f\00E9rerez peut-\00EAtre choisir <strong>Oui</strong> et entrer uniquement des administrateurs d''application, et \00E9ventuellement')
||' des contributeurs.<br>',
unistr('Si vous s\00E9lectionnez <strong>Oui</strong>, vous devez \00E9galement indiquer le mode de traitement des utilisateurs qui ne figurent pas sur la liste des utilisateurs.</p>'),
unistr('<p>Indiquez si une adresse \00E9lectronique ou une valeur alphanum\00E9rique est requise pour les noms utilisateur.<br>'),
unistr('G\00E9n\00E9ralement, vous devrez d\00E9finir ce param\00E8tre sur <strong>Adresse \00E9lectronique</strong> si votre application utilise (ou sera configur\00E9e pour utiliser) un mod\00E8le d''authentification centralis\00E9 tel qu''Oracle Access Manager ou l''acc\00E8s avec connexion un')
||'ique.</p>',
unistr('<p><em><strong>Remarque :</strong> cette application prend en charge les 3 niveaux d''acc\00E8s suivants : Lecteur, Contributeur et Administrateur.'),
'<ul>',
unistr('  <li>Les <strong>lecteurs</strong> disposent d''un acc\00E8s en lecture seule \00E0 toutes les informations et peuvent \00E9galement consulter les \00E9tats.</li>'),
unistr('  <li>Les <strong>contributeurs</strong> peuvent cr\00E9er, modifier et supprimer des informations et consulter les \00E9tats.</li>'),
unistr('  <li>Les <strong>administrateurs</strong>, outre les capacit\00E9s des contributeurs, peuvent \00E9galement ex\00E9cuter la configuration de l''application en acc\00E9dant \00E0 sa section Administration.</li>'),
'</ul>',
'</em></p>'))
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220124234841'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31617292523055976137)
,p_plug_name=>unistr('Configuration du contr\00F4le d''acc\00E8s')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(31616762263951974244)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31617292620076976137)
,p_plug_name=>'Boutons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(31616765079390974245)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31617293845813976138)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(31617292620076976137)
,p_button_name=>'APPLY_CHANGES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Appliquer les modifications'
,p_button_position=>'CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31617294129058976138)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(31617292620076976137)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_image_alt=>'Annuler'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(31617295501873976139)
,p_branch_name=>'Branchement sur la page d''administration'
,p_branch_action=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31617295896771976139)
,p_name=>'P10040_ALLOW_OTHER_USERS'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(31617292523055976137)
,p_prompt=>unistr('Tous les utilisateurs authentifi\00E9s peuvent acc\00E9der \00E0 cette application')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_app_setting.get_value( p_name => ''ACCESS_CONTROL_SCOPE'' ) = ''ACL_ONLY'' then',
'    return ''N'';',
'else',
'    return ''Y'';',
'end if;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_YES_NO'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_api.id(31616886559077974292)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>unistr('S\00E9lectionnez <strong>Non</strong> si tous les utilisateurs sont d\00E9finis dans la liste de contr\00F4le d''acc\00E8s. S\00E9lectionnez <strong>Oui</strong> si les utilisateurs authentifi\00E9s ne figurant pas dans la liste de contr\00F4le d''acc\00E8s peuvent \00E9galement utiliser')
||' cette application.'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(31617294256371976138)
,p_name=>unistr('Annuler la bo\00EEte de dialogue')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(31617294129058976138)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(31617294923890976139)
,p_event_id=>wwv_flow_api.id(31617294256371976138)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31617296250943976140)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('D\00E9finir le contr\00F4le d''acc\00E8s')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :P10040_ALLOW_OTHER_USERS = ''Y'' then',
'        apex_app_setting.set_value (',
'            p_name  => ''ACCESS_CONTROL_SCOPE'',',
'            p_value => ''ALL_USERS'');',
'    else',
'        apex_app_setting.set_value (',
'            p_name  => ''ACCESS_CONTROL_SCOPE'',',
'            p_value => ''ACL_ONLY'');',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('Param\00E8tres de contr\00F4le d''acc\00E8s enregistr\00E9s.')
);
wwv_flow_api.component_end;
end;
/
