prompt --application/pages/page_00044
begin
--   Manifest
--     PAGE: 00044
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>44
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>'Liste des utilisateurs'
,p_alias=>'LISTE-DES-UTILISATEURS'
,p_step_title=>'Liste des utilisateurs'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220218104202'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39789155443744976748)
,p_plug_name=>'Etat 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616812390454974262)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'USERS'
,p_query_where=>'PROFILE != ''Administrateur'''
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Etat 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39789155870508976748)
,p_name=>'Etat 1'
,p_max_row_count_message=>unistr('Le nombre maximal de lignes pour cet \00E9tat est de #MAX_ROW_COUNT# lignes. Appliquez un filtre pour r\00E9duire le nombre d''enregistrements dans votre requ\00EAte.')
,p_no_data_found_message=>unistr('Aucune donn\00E9e n''a \00E9t\00E9 trouv\00E9e.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:RP:P45_ROWID:\#ROWID#\'
,p_detail_link_text=>'<span aria-label="Modifier"><span class="fa fa-edit" aria-hidden="true" title="Modifier"></span></span>'
,p_owner=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_internal_uid=>39789155870508976748
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39789155928722976750)
,p_db_column_name=>'ROWID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'ROWID'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39789157112375976751)
,p_db_column_name=>'USERNAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Username'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39789157550021976751)
,p_db_column_name=>'EMAIL'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290796106698466324)
,p_db_column_name=>'NOM'
,p_display_order=>15
,p_column_identifier=>'F'
,p_column_label=>'Nom'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290796275091466325)
,p_db_column_name=>'PRENOM'
,p_display_order=>25
,p_column_identifier=>'G'
,p_column_label=>'Prenom'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290796312451466326)
,p_db_column_name=>'PROFILE'
,p_display_order=>35
,p_column_identifier=>'H'
,p_column_label=>'Profile'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(39789161563153977442)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'397891616'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ROWID:LOGIN_PK_FK:USERNAME:EMAIL:NOM:PRENOM:PROFILE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39789158050561976751)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(39789155443744976748)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45'
);
wwv_flow_api.component_end;
end;
/
