prompt --application/pages/page_00048
begin
--   Manifest
--     PAGE: 00048
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>48
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>'Edit infos perso'
,p_alias=>'EDIT-INFOS-PERSO'
,p_page_mode=>'MODAL'
,p_step_title=>'Modifier mes informations'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220216140144'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(79771175757212428456)
,p_plug_name=>'Informations'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(31616816680959974263)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'APP_USERS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33574999820153043541)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_button_name=>'CONFIRMER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Confirmer'
,p_button_position=>'CHANGE'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33575000574605043548)
,p_name=>'P48_LOGIN_PK'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_item_source_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_item_default=>':P47_USER_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'LOGIN_PK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33575000682663043549)
,p_name=>'P48_PROFILE_OWNER_FK'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_item_source_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_prompt=>'Profile Owner Fk'
,p_source=>'PROFILE_OWNER_FK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33575000707529043550)
,p_name=>'P48_PROFILE_FK'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_item_source_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_prompt=>'Profile Fk'
,p_source=>'PROFILE_FK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918001842326075328)
,p_name=>'P48_NOM'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_prompt=>'Nom'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.NOM as NOM',
'from APP_USERS ',
'where  lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918002226521075328)
,p_name=>'P48_PRENOM'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_prompt=>unistr('Pr\00E9nom')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.PRENOM as PRENOM',
'from APP_USERS ',
'where  lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918002654741075328)
,p_name=>'P48_USERNAME'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_prompt=>'Username'
,p_source=>':APP_USER'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918003056669075328)
,p_name=>'P48_EMAIL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_prompt=>'E-mail'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'EMAIL'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39918003478868075328)
,p_name=>'P48_PASSWD'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(79771175757212428456)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Password'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.PASSWD',
' from  APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39950533789441832311)
,p_name=>'GET PROFILE_FK'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39950533860216832312)
,p_event_id=>wwv_flow_api.id(39950533789441832311)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_PROFILE_FK'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROFILE_FK from APP_USERS ',
' where lower(USERNAME)=lower(:APP_USER)'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39950534735796832321)
,p_name=>'GET PROFILE_OWNER_FK'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39950534865397832322)
,p_event_id=>wwv_flow_api.id(39950534735796832321)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_PROFILE_OWNER_FK'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROFILE_FK from APP_USERS ',
' where lower(USERNAME)=lower(:APP_USER)'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39950533964734832313)
,p_name=>'GET NOM'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39950534027206832314)
,p_event_id=>wwv_flow_api.id(39950533964734832313)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_NOM'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.NOM as NOM',
'from APP_USERS ',
'where  lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39950534120333832315)
,p_name=>'GET PRENOM'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39950534270754832316)
,p_event_id=>wwv_flow_api.id(39950534120333832315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_PRENOM'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.PRENOM as PRENOM',
'from APP_USERS ',
'where  lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39950534388444832317)
,p_name=>'GET EMAIL'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39950534411101832318)
,p_event_id=>wwv_flow_api.id(39950534388444832317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_EMAIL'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.EMAIL as EMAIL',
' from  APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(33575000368650043546)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Modifier Infos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE APP_USERS set  NOM = :P48_NOM,',
'PRENOM = :P48_PRENOM, email = :P48_EMAIL where lower(username) = lower(:APP_USER);',
'UPDATE ETUDIANTS set  NOM = :P48_NOM,',
'PRENOM = :P48_PRENOM where USER_ID =',
' (select LOGIN_PK from APP_USERS where lower(username)=lower(:APP_USER));'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Erreur de modification dans la base de donn\00E9es!')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('Modification effectu\00E9es avec succ\00E8s.')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(33575000491139043547)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(79771175757212428456)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialiser le panneau Edit infos perso'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
