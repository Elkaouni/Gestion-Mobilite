prompt --application/pages/page_00047
begin
--   Manifest
--     PAGE: 00047
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>47
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>'Informations personnelles'
,p_alias=>'INFOS-PERSONNELLES'
,p_step_title=>'Infos personnelles'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220218140203'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39853174875380353142)
,p_plug_name=>'Informations'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(31616816680959974263)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33575000085827043543)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_button_name=>'MODIFIER_MDP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(31616889318707974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Modifier MDP'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-lock-password'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33574999633472043539)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_button_name=>'Modifier'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(31616889318707974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Modifier'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574997479629043517)
,p_name=>'P47_USER_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574997570659043518)
,p_name=>'P47_NOM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Nom'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.NOM as NOM',
'from APP_USERS ',
'where  lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574997671298043519)
,p_name=>'P47_PRENOM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Pr\00E9nom')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.PRENOM as PRENOM',
'from APP_USERS ',
'where  lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574997775489043520)
,p_name=>'P47_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_prompt=>'Username'
,p_source=>':APP_USER'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574997802372043521)
,p_name=>'P47_EMAIL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_use_cache_before_default=>'NO'
,p_prompt=>'E-mail'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.EMAIL as EMAIL',
' from  APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'EMAIL'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574997916732043522)
,p_name=>'P47_PASSWD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Password'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.PASSWD',
' from  APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574998035874043523)
,p_name=>'P47_CNE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_prompt=>'CNE'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ETUDIANTS.CNE as CNE',
'from ETUDIANTS ETUDIANTS',
'where ETUDIANTS.USER_ID = (select APP_USERS.LOGIN_PK as LOGIN_PK',
' from APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ETUDIANTS.CNE as CNE',
'from ETUDIANTS ETUDIANTS',
'where ETUDIANTS.USER_ID = (select APP_USERS.LOGIN_PK as LOGIN_PK',
' from APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER))'))
,p_display_when_type=>'EXISTS'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574998198917043524)
,p_name=>'P47_FILIERE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_prompt=>unistr('Fili\00E8re')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select FILIERE.NOM_FILIERE as NOM_FILIERE',
'from FILIERE FILIERE where FILIERE.NOM_FILIERE = (select ',
'    ETUDIANTS.FILIERE as FILIERE from ETUDIANTS ETUDIANTS ',
'    where ETUDIANTS.USER_ID = (select APP_USERS.LOGIN_PK as LOGIN_PK',
' from APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER)))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select FILIERE.NOM_FILIERE as NOM_FILIERE',
'from FILIERE FILIERE where FILIERE.NOM_FILIERE = (select ',
'    ETUDIANTS.FILIERE as FILIERE from ETUDIANTS ETUDIANTS ',
'    where ETUDIANTS.USER_ID = (select APP_USERS.LOGIN_PK as LOGIN_PK',
' from APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER)))'))
,p_display_when_type=>'EXISTS'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574998242302043525)
,p_name=>'P47_POOL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NOM_POOL from POOL where ID=(select POOL_ID',
'from FILIERE FILIERE where FILIERE.NOM_FILIERE = (select ',
'    ETUDIANTS.FILIERE as FILIERE from ETUDIANTS ETUDIANTS ',
'    where ETUDIANTS.USER_ID = (select APP_USERS.LOGIN_PK as LOGIN_PK',
' from APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER))))'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Pool'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NOM_POOL from POOL where ID=(select POOL_ID',
'from FILIERE FILIERE where FILIERE.NOM_FILIERE = (select ',
'    ETUDIANTS.FILIERE as FILIERE from ETUDIANTS ETUDIANTS ',
'    where ETUDIANTS.USER_ID = (select APP_USERS.LOGIN_PK as LOGIN_PK',
' from APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER))))'))
,p_display_when_type=>'EXISTS'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574998304884043526)
,p_name=>'P47_PROFILE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(39853174875380353142)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.PROFILE_FK ',
' from APP_USERS APP_USERS where lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Profil'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROFILES.PROFILE_NAME as PROFILE_NAME,',
'    PROFILES.PROFILE_PK as PROFILE_PK ',
' from PROFILES PROFILES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39940149794233926308)
,p_name=>'Modifier Infos'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(39853174875380353142)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39940149833593926309)
,p_event_id=>wwv_flow_api.id(39940149794233926308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(39853174875380353142)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39950532756780832301)
,p_name=>'Get User ID'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39950532861535832302)
,p_event_id=>wwv_flow_api.id(39950532756780832301)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P47_USER_ID'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.LOGIN_PK as LOGIN_PK  from APP_USERS APP_USERS',
'  where lower(APP_USERS.USERNAME) = lower(:APP_USER);',
''))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39950532984554832303)
,p_name=>'Get nom'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39950533003464832304)
,p_event_id=>wwv_flow_api.id(39950532984554832303)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P47_NOM'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APP_USERS.NOM as NOM',
'from APP_USERS ',
'where  lower(APP_USERS.USERNAME) = lower(:APP_USER)'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
