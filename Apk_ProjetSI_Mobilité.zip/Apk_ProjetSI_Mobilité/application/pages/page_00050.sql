prompt --application/pages/page_00050
begin
--   Manifest
--     PAGE: 00050
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>50
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>'Modifier MDP'
,p_alias=>'MODIFIER-MDP'
,p_page_mode=>'MODAL'
,p_step_title=>'Modifier MDP'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220216232944'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39950535044837832323)
,p_plug_name=>unistr('Remplir donn\00E9es :')
,p_region_name=>':P50_LOGIN_PK'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(31616816680959974263)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'TABLE'
,p_query_table=>'APP_USERS'
,p_include_rowid_column=>true
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39950536888660832341)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_button_name=>'Modifier'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Modifier'
,p_button_position=>'CHANGE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39950535274861832325)
,p_name=>'P50_OLD_PASSWD'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_item_source_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_prompt=>'Old Passwd'
,p_source=>'PASSWD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39950535498914832327)
,p_name=>'P50_USERNAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_item_source_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_item_default=>':APP_USER'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Username'
,p_source=>'USERNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39950535579938832328)
,p_name=>'P50_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_item_source_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39950536180925832334)
,p_name=>'P50_NEW_PWD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_prompt=>'New Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39950536257479832335)
,p_name=>'P50_CONFIRM_NEW_PWD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39950535044837832323)
,p_prompt=>'Confirm New Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(39950536542452832338)
,p_validation_name=>'confirm'
,p_validation_sequence=>10
,p_validation=>':P50_NEW_PWD = :P50_CONFIRM_NEW_PWD'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Veuillez entrer le m\00EAme mot de passe')
,p_associated_item=>wwv_flow_api.id(39950536180925832334)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(39950536665279832339)
,p_validation_name=>'correct pwd'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare old_pwd APP_USERS.PASSWD%type;',
'begin ',
'select PASSWD into old_pwd from APP_USERS where lower(USERNAME) = lower(:APP_USER);',
'if :P50_OLD_PASSWD=old_pwd then ',
'return true;',
'else return false;',
'end if;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Mot de passe incorrect!'
,p_associated_item=>wwv_flow_api.id(39950535274861832325)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39950536737983832340)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update pwd'
,p_process_sql_clob=>'UPDATE APP_USERS set  PASSWD = :P50_NEW_PWD where lower(username) = lower(:APP_USER);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(39950536888660832341)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39950535124569832324)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(39950535044837832323)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialiser le panneau Modifier MDP'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
