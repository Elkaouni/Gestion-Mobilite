prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>28
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>unistr('Choix de mobilit\00E9')
,p_alias=>unistr('CHOIX-DE-MOBILIT\00C9')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Choix de mobilit\00E9')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220216224249'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39430804190659991076)
,p_plug_name=>unistr('Choix de mobilit\00E9')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616762263951974244)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'TABLE'
,p_query_table=>'ECOLES_ETUDIANTS'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39430807258840991080)
,p_plug_name=>'Boutons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616765079390974245)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39430807611359991081)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(39430807258840991080)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_image_alt=>'Annuler'
,p_button_position=>'CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39430809088281991083)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(39430807258840991080)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_image_alt=>'Supprimer'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P28_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39430809418809991083)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(39430807258840991080)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Appliquer les modifications'
,p_button_position=>'NEXT'
,p_button_condition=>'P28_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39430809883455991083)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(39430807258840991080)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'NEXT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33574996724392043510)
,p_name=>'P28_NOMBRE_PLACES'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39430804466469991076)
,p_name=>'P28_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_item_source_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39430804828505991077)
,p_name=>'P28_ECOLES'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_item_source_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_prompt=>'Ecoles'
,p_source=>'ECOLE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ECOLES.NOM_ECOLE as NOM_ECOLE, ECOLES.ID as ID',
'from ECOLES ECOLES',
'    '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39430805226763991079)
,p_name=>'P28_ORDRE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_item_source_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_prompt=>'Ordre'
,p_source=>'ORDRE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:1er choix;1,2\00E8me choix;2,3\00E8me choix;3')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39430805614072991079)
,p_name=>'P28_TYPE_MOBILITE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_item_source_plug_id=>wwv_flow_api.id(39430804190659991076)
,p_prompt=>'Type Mobilite'
,p_source=>'TYPE_MOBILITE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Double Diplomation;DD,Echange;ECH'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(31616886787934974292)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39430807713382991081)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(39430807611359991081)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39430808590426991082)
,p_event_id=>wwv_flow_api.id(39430807713382991081)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39950537576579832348)
,p_name=>'Get Nombre'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P28_ECOLES,P28_TYPE_MOBILITE'
,p_condition_element=>'P28_TYPE_MOBILITE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P28_ECOLES'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39950537619124832349)
,p_event_id=>wwv_flow_api.id(39950537576579832348)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P28_NOMBRE_PLACES'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    nombre number;',
'begin',
'    if V(:P28_TYPE_MOBILITE) = ''Double Diplomation'' then ',
'        select PLACES_DD into nombre from NOMBRE_PLACES where',
'        ECOLE_ID = V(:P28_ECOLES);',
'    elsif V(:P28_TYPE_MOBILITE) = ''ECH'' then ',
'        select PLACES_ECHANGE into nombre from NOMBRE_PLACES where',
'        ECOLE_ID = V(:P28_ECOLES);',
'    elsif V(:P28_TYPE_MOBILITE) = ''NULL'' then nombre := 12;',
'    else nombre := 10;',
'    end if;',
'    return nombre;',
'end;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39430810632087991083)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Traiter le panneau Choix de mobilit\00E9')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into ECOLES_ETUDIANTS (ECOLE_ID, ETUDIANT_ID, TYPE_MOBILITE,ORDRE)',
'values(',
'    :P28_ECOLES, ',
'    (select id from etudiants where user_id = ',
'    (select login_pk from APP_USERS where lower(username) = lower(:APP_USER))),',
'    :P28_TYPE_MOBILITE,',
'    :P28_ORDRE',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(39430809883455991083)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39430811051621991084)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('Fermer la bo\00EEte de dialogue')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39430810228677991083)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(39430804190659991076)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialiser le panneau Choix de mobilit\00E9')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
