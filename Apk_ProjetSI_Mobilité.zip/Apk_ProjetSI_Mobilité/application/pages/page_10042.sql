prompt --application/pages/page_10042
begin
--   Manifest
--     PAGE: 10042
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>10042
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>unistr('G\00E9rer l''acc\00E8s utilisateur')
,p_alias=>'USER_ACCESS'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('G\00E9rer l''acc\00E8s utilisateur')
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(31616919758754974313)
,p_required_role=>wwv_flow_api.id(31616918188552974311)
,p_required_patch=>wwv_flow_api.id(31616915412552974309)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>Utilisez ce formulaire pour entrer des utilisateurs et leur adresse \00E9lectronique, et d\00E9finir leur niveau d''acc\00E8s.'),
unistr('Les param\00E8tres d\00E9finis dans <em>Configurer le contr\00F4le d''acc\00E8s</em> d\00E9termineront si le nom utilisateur doit \00EAtre leur adresse \00E9lectronique ou s''il peut s''agir de n''importe quelle entr\00E9e alphanum\00E9rique.</p>'),
unistr('<p>Cette application prend en charge les 3 niveaux d''acc\00E8s suivants : Lecteur, Contributeur et Administrateur.</p>'),
'<ul>',
unistr('  <li>Les <strong>lecteurs</strong> disposent d''un acc\00E8s en lecture seule \00E0 toutes les informations et peuvent \00E9galement consulter les \00E9tats.</li>'),
unistr('  <li>Les <strong>contributeurs</strong> peuvent cr\00E9er, modifier et supprimer des informations et consulter les \00E9tats.</li>'),
unistr('  <li>Les <strong>administrateurs</strong>, outre les capacit\00E9s des contributeurs, peuvent \00E9galement ex\00E9cuter la configuration de l''application en acc\00E9dant \00E0 sa section Administration.</li>'),
'</ul>',
unistr('<p>Lorsque vous modifiez un utilisateur existant, vous pouvez verrouiller son compte, ce qui l''emp\00EAchera d''acc\00E9der \00E0 l''application.</p>'),
unistr('<p><em><strong>Remarque :</strong>   si vous utilisez des comptes Oracle Application Express, les utilisateurs entr\00E9s ici doivent \00E9galement \00EAtre d\00E9finis en tant qu''utilisateurs finals par un administrateur d''espace de travail, qui peut aussi d\00E9finir ')
||'leur mot de passe.</em></p>'))
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220118223828'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31617302097268976284)
,p_plug_name=>unistr('Panneau sur G\00E9rer l''acc\00E8s utilisateur')
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(31616762263951974244)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'APEX_APPL_ACL_USERS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31617302182490976284)
,p_plug_name=>'Boutons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(31616765079390974245)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31617304917982976286)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(31617302182490976284)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Appliquer les modifications'
,p_button_position=>'NEXT'
,p_button_condition=>'P10042_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31617305352613976287)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(31617302182490976284)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ajouter un utilisateur'
,p_button_position=>'NEXT'
,p_button_condition=>'P10042_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31617303130097976286)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(31617302182490976284)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_image_alt=>'Annuler'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31617304545774976286)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(31617302182490976284)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_image_alt=>'Supprimer'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10042_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31617305675255976287)
,p_name=>'P10042_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(31617302097268976284)
,p_item_source_plug_id=>wwv_flow_api.id(31617302097268976284)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31617306043181976287)
,p_name=>'P10042_APPLICATION_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(31617302097268976284)
,p_item_source_plug_id=>wwv_flow_api.id(31617302097268976284)
,p_use_cache_before_default=>'NO'
,p_item_default=>'&APP_ID.'
,p_source=>'APPLICATION_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31617306430354976287)
,p_name=>'P10042_USER_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(31617302097268976284)
,p_item_source_plug_id=>wwv_flow_api.id(31617302097268976284)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Nom utilisateur'
,p_source=>'USER_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_read_only_when=>'P10042_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(31616888076095974293)
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(31617306822573976288)
,p_name=>'P10042_ROLE_IDS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(31617302097268976284)
,p_item_source_plug_id=>wwv_flow_api.id(31617302097268976284)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('R\00F4les')
,p_source=>'ROLE_IDS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'ACCESS_ROLES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select role_name d, role_id r',
'from APEX_APPL_ACL_ROLES where application_id = :APP_ID ',
'order by 1'))
,p_field_template=>wwv_flow_api.id(31616888076095974293)
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>Lorsque le contr\00F4le d''acc\00E8s est activ\00E9, les administrateurs ont la possibilit\00E9 de restreindre l''acc\00E8s \00E0 certaines fonctionnalit\00E9s d''application pour les utilisateurs authentifi\00E9s. Cette application prend en charge les 3 r\00F4les suivants : Lecteur, C')
||'ontributeur et Administrateur.<p>',
'<ul>',
unistr('  <li>Les <strong>lecteurs</strong> disposent d''un acc\00E8s en lecture seule \00E0 toutes les informations et peuvent \00E9galement consulter les \00E9tats.</li>'),
unistr('  <li>Les <strong>contributeurs</strong> peuvent cr\00E9er, modifier et supprimer des informations et consulter les \00E9tats.</li>'),
unistr('  <li>Les <strong>administrateurs</strong>, outre les capacit\00E9s des contributeurs, peuvent \00E9galement ex\00E9cuter la configuration de l''application.</li>'),
'</ul>'))
,p_attribute_01=>'1'
,p_attribute_02=>'VERTICAL'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(31617308271034976293)
,p_validation_name=>unistr('Impossible de vous enlever vous-m\00EAme en tant qu''administrateur')
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P10042_USER_NAME = :APP_USER and',
'    apex_acl.is_role_removed_from_user (',
'        p_application_id => :APP_ID,',
'        p_user_name      => :APP_USER,',
'        p_role_static_id => ''ADMINISTRATOR'',',
'        p_role_ids       => apex_string.split_numbers(',
'                                p_str => case when :REQUEST = ''DELETE'' then',
'                                             null',
'                                         else',
'                                             :P10042_ROLE_IDS',
'                                         end,',
'                                p_sep => '':'') ) then',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Vous ne pouvez pas enlever votre propre r\00F4le d''administrateur.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(31617303214249976286)
,p_name=>unistr('Annuler la bo\00EEte de dialogue')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(31617303130097976286)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(31617303957237976286)
,p_event_id=>wwv_flow_api.id(31617303214249976286)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31617308517547976293)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_region_id=>wwv_flow_api.id(31617302097268976284)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialiser le panneau G\00E9rer l''acc\00E8s utilisateur')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31617308939843976293)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(31617302097268976284)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Traiter le panneau G\00E9rer l''acc\00E8s utilisateur')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'N'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31617309396609976293)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('Fermer la bo\00EEte de dialogue')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
