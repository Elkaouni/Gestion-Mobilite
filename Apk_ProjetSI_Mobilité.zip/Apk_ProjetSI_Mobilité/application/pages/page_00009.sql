prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>unistr('Choix de mobilit\00E9')
,p_alias=>unistr('CHOIX-DE-MOBILIT\00C91')
,p_step_title=>unistr('Choix de mobilit\00E9')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'YOUSRA'
,p_last_upd_yyyymmddhh24miss=>'20220218020555'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39430811652422991087)
,p_plug_name=>'Etat 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616812390454974262)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'DESIDERATA'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ETUDIANT =(select ID from ETUDIANTS ',
'where USER_ID=(select LOGIN_PK from APP_USERS where lower(USERNAME)=lower(:APP_USER)))',
''))
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Etat 1'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(40290694450433466307)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_internal_uid=>40290694450433466307
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290694511473466308)
,p_db_column_name=>'ROWID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Rowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290694688023466309)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290795708241466320)
,p_db_column_name=>'ETUDIANT'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Etudiant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290795873669466321)
,p_db_column_name=>'CHOIX'
,p_display_order=>40
,p_column_identifier=>'H'
,p_column_label=>'Choix'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290795993402466322)
,p_db_column_name=>'ECOLE'
,p_display_order=>50
,p_column_identifier=>'I'
,p_column_label=>'Ecole'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40290796064131466323)
,p_db_column_name=>'MOBILITE'
,p_display_order=>60
,p_column_identifier=>'J'
,p_column_label=>'Mobilite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(40291520016357174176)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'402915201'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ROWID:ID_ID_ID:TYPE_ETUDIANT:CHOIX:ECOLE:MOBILITE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39880807264534388519)
,p_plug_name=>'Etat 2'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616812390454974262)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'AFFECTATION'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'cne =(select cne from ETUDIANTS ',
'where USER_ID=(select LOGIN_PK from APP_USERS where lower(USERNAME)=lower(:APP_USER)))',
''))
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_JQM_REFLOW'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STRIPE:STROKE'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(39880808973900388536)
,p_name=>'TYPE_AFF'
,p_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading=>'Type Aff'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'PLAIN'
,p_attribute_08=>'N'
,p_escape_on_http_output=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(39880809010806388537)
,p_name=>'ROWID'
,p_data_type=>'ROWID'
,p_is_visible=>false
,p_display_sequence=>40
,p_attribute_01=>'PLAIN'
,p_attribute_08=>'N'
,p_escape_on_http_output=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(39880809140036388538)
,p_name=>'CNE'
,p_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading=>'Cne'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'PLAIN'
,p_attribute_08=>'N'
,p_escape_on_http_output=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(39880809221920388539)
,p_name=>'NOM_ECOLE'
,p_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading=>'Nom Ecole'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'PLAIN'
,p_attribute_08=>'N'
,p_escape_on_http_output=>true
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39430813084343991087)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(39430811652422991087)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Faire mon choix'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:28'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare choix number;',
'begin ',
'select count(*) into choix',
' from ECOLES_ETUDIANTS ECOLES_ETUDIANTS',
' where ECOLES_ETUDIANTS.ETUDIANT_ID =(select ID from ETUDIANTS ',
' where USER_ID=(select LOGIN_PK from APP_USERS where lower(USERNAME)=lower(:APP_USER)));',
' if choix <3 then return true;',
' else return false;',
' end if;',
' end;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39430812023352991087)
,p_name=>unistr('Modifier un \00E9tat - Bo\00EEte de dialogue ferm\00E9e')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(39430811652422991087)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39430812558189991087)
,p_event_id=>wwv_flow_api.id(39430812023352991087)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(39430811652422991087)
);
wwv_flow_api.component_end;
end;
/
