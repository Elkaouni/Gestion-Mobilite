prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>27202335253127247240
,p_default_application_id=>100711
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJETS'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(31616913957114974305)
,p_name=>'Administrateur'
,p_alias=>'ADMINISTRATEUR'
,p_step_title=>'Administrateur'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>Pour rechercher des donn\00E9es, entrez un terme de recherche dans la bo\00EEte de dialogue de recherche, ou cliquez sur les en-t\00EAtes de colonne pour limiter les enregistrements renvoy\00E9s.</p>'),
'',
unistr('<p>Vous pouvez ex\00E9cuter de nombreuses fonctions en cliquant sur le bouton <strong>Actions</strong>. Ainsi, vous pouvez s\00E9lectionner les colonnes \00E0 afficher/masquer et leur s\00E9quence d''affichage, mais aussi de nombreuses fonctions relatives aux donn\00E9es')
||unistr(' et aux formats. Vous pouvez \00E9galement d\00E9finir des vues de donn\00E9es suppl\00E9mentaires \00E0 l''aide des options Graphique, Grouper par et Permuter.</p>'),
'',
unistr('<p>Pour enregistrer vos personnalisations, s\00E9lectionnez l''\00E9tat ou cliquez sur le bouton de t\00E9l\00E9chargement pour d\00E9charger les donn\00E9es. Entrez votre adresse \00E9lectronique et l''intervalle de temps dans l''abonnement selon lequel envoyer les donn\00E9es r\00E9guli')
||unistr('\00E8rement.<p>'),
'',
'<p>Pour plus d''informations, cliquez sur Aide au bas du menu Actions.</p>',
'',
unistr('<p>Pour r\00E9tablir les param\00E8tres par d\00E9faut de l''\00E9tat interactif, cliquez sur le bouton <strong>R\00E9initialiser</strong>.</p>')))
,p_last_updated_by=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_last_upd_yyyymmddhh24miss=>'20220118223819'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31616995315512974728)
,p_plug_name=>'Administrateur'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616812390454974262)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'ADMINISTRATEUR'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Administrateur'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(31616995457345974728)
,p_name=>'Administrateur'
,p_max_row_count_message=>unistr('Le nombre maximal de lignes pour cet \00E9tat est de #MAX_ROW_COUNT# lignes. Appliquez un filtre pour r\00E9duire le nombre d''enregistrements dans votre requ\00EAte.')
,p_no_data_found_message=>unistr('Aucune donn\00E9e n''a \00E9t\00E9 trouv\00E9e.')
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:11:&APP_SESSION.:::11:P11_ID:\#ID#\'
,p_detail_link_text=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_detail_link_auth_scheme=>wwv_flow_api.id(31616918394049974311)
,p_owner=>'MAHA_DRISSIELBOUZAIDI@UM5.AC.MA'
,p_internal_uid=>31616995457345974728
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31616995871171974729)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31616996200275974730)
,p_db_column_name=>'USERS_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Users'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_api.id(31616996617430974730)
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(31617144238153975420)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'316171443'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USERS_ID'
,p_sort_column_1=>'USERS_ID'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31616998074935974731)
,p_plug_name=>'Chemin de navigation'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(31616828752682974268)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(31616725863228974225)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(31616890825385974294)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31616997256087974730)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(31616995315512974728)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(31616889318707974294)
,p_button_image_alt=>unistr('R\00E9initialiser')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31616999816603974732)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(31616995315512974728)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(31616889204945974294)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11'
,p_security_scheme=>wwv_flow_api.id(31616918394049974311)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(31616998939038974732)
,p_name=>unistr('Modifier un \00E9tat - Bo\00EEte de dialogue ferm\00E9e')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(31616995315512974728)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(31616999489407974732)
,p_event_id=>wwv_flow_api.id(31616998939038974732)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(31616995315512974728)
);
wwv_flow_api.component_end;
end;
/
